
<!DOCTYPE html>
<html lang="en">
<?php 
       
        $link = mysqli_connect("localhost", "root", "", "lightbox");

       
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">    
    <title>EVENTS</title>
   
</head>

<body>


<!-- navbar  -->
<div class="navbar">
    <a id="main" class="logo" href="../index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="../index.php">Home</a></li>
<li><a id="head" href="events.php">Events</a></li>
<li><a id="head" href="../gallery.php">Gallery</a></li>

<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="../user/index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="../user/login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>

</ul>
</div>

    
        <section class="Form my-4 mx-5">
            <div class="container" style="width:">
                
                <div class="row no-gutters">
                
                   
                    <div class="col-md-5"><img src="i1.jpg" class="img-fluid"> </div>
                    <div class="col-md-7">   
                        <form  action="" method="POST">
                            <div class="form-row"> 
                                <div class="col-md-7 mx-5 my-2 p-5">
                                           
                                <input placeholder="First Name" type="text" name="Name" required class="form-control my-3 p-1">
                                
                                <input placeholder="Email" type="text" name="email" class="form-control my-3 p-1">
                                
                                <input placeholder="Phone Number" type="text" name="pNumber" required class="form-control my-3 p-1">
                               
                                <select name="event" required class="form-control my-3 p-1">   
                                    <option value="" disabled selected>Select Event</option>
                                    <option value="Magic of everyday">Magic of everyday</option>
                                    <option value="Cultures">Cultures</option>
                                    <option value="Dark">Dark</option>
                                    
                                </select>

                                                           

                                <button type="submit" value="submit" name="submit" class="btn1 my-3 p-1" >Register</button>
                                <?php
                                                       
                                if(isset($_POST['submit'])){
                                
                                    $uname= mysqli_real_escape_string($link,$_POST['Name']);
                                    $uevent= mysqli_real_escape_string($link,$_POST['event']);
                                    $query="SELECT   U_Name,events FROM bookevent WHERE  U_Name='$uname' and events='$uevent'";
                                    $result = mysqli_query($link, $query); 

                                    if(mysqli_num_rows($result)>0) {
                                        while($row=  mysqli_fetch_assoc($result)){
                                                echo"<script>alert('You have already registered for this event!')</script>";
                                            
                                        }
                                           
                                    }
        
                                    else{
                                                                      
                                    $insert_query = "INSERT INTO 
                                    bookevent( 
                                                    U_Name,
                                                    U_email,
                                                    U_pNumber,
                                                    events)
                                    VALUES (        
                                                                                                        
                                                    '".$_POST["Name"]."',
                                                    '".$_POST["email"]."',
                                                    '".$_POST["pNumber"]."',
                                                    '".$_POST["event"]."')";
                                    mysqli_query($link,$insert_query);
                                    
                                    $email= $_POST['email'];
                                    $event= $_POST['event'];
                                    $name= $_POST['Name'];
                                    
                                    $to_email = "$email";
                                    $subject = "Aurora Events";
                                    $body = "    Hi, $name you have registered for the $event event.
                                    Thank you for Participating $name! Have a great day!";
                                    $headers = "From: AURORApx@gmail.com";

                                    if (mail($to_email, $subject, $body, $headers)) {
                                    echo "<script>  alert ('Hey! $name you have successfully Registered !');</script>";
                                      } else {
                                        echo "<script>alert('failed to register...');</script>";
                                       }
                                    
                                    }
                                   
                                }
                                ?>
                            </form>
                        </div>
                                             
                </div>
            </div>
        </section> 
        
    <script>
        if ( window.history.replaceState ) {
            window.history.replaceState( null, null, window.location.href );
        }
    </script>                    
    <script src="scripts/jquery-3.3.1.min.js "></script>
    <script src="scripts/script.js "></script>


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>
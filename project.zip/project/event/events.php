


<!DOCTYPE html>
<html>
<head>
 <title>EVENTS</title>
<link rel="stylesheet" href="style1.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Xanh+Mono:ital@1&display=swap" rel="stylesheet">
<!-- Required meta tags -->
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" />

    <!-- <script>
      function eventFunction(x) {
      if (x==="culture") {
	     alert("you have registered for");
        
       
       }
    </script> -->

</head>
<body>
 <div class="full">   
<!-- navbar  -->
<div class="navbar">
    <a id="main" class="logo" href="../index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="../index.php">Home</a></li>
<li><a id="head" href="events.php">Events</a></li>
<li><a id="head" href="../gallery.php">Gallery</a></li>
<!-- <li><a id="head" href="users/">Login/Upload</a></li> -->
<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="../user/index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="../user/login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>

</ul>
</div>

<div>
<img src="i4.jpg" class="img">
</div>
<br>
<br>
<center><h3>EVENTS</h3></center>
<center><p>_________________________________________________________</p></center>
<br>

<div class="down">
<br><br>
<div class="container">
        <div class="row">

          <div class="col-sm-4 imghov">
            <br>
            <h5>Magic of the Everyday</h5>
            <br>
            <img class="row-image" src="i5.jpg">
          </div>

          <div class="col-sm-8 imghov">
            <br><br>
            <p ><pre style="color:white ;font-family: 'Xanh Mono', monospace;">
            Concerned with everyday life, ordinary activities, 
            states of mind and conditions of existence that fill time outside 
            the moments of drama and spectacle, these artists explore the experience 
            of the mundane and seemingly precious.

            DATE OF EVENT: 4th-6th December 
            </pre></p>

            
            <button class="button button4"><a id="txt" href="bookevent.php">Register</a></button>  
          </div>
          
        </div>
        <br>
</div>
<br><br>
<div class="container">
        <div class="row">

          <div class="col-sm-4 imghov">
            <br>
            <h5>CULTURES</h5>
            <br>
            <img class="row-image" src="i6.jpg">
          </div>

          <div class="col-sm-8 imghov">
            <br><br>
            <p ><pre style="color:white ;font-family: 'Xanh Mono', monospace;">
            This month, our focus is on culture, specifically "What does my culture mean to me",
            a topic that supports our mission to create a collection of authentic images to reflect 
            the cultural diversity of the world we live in. Share your unique point of view with us.

            DATE OF EVENT: 28th-29th December
            </pre></p>
            <button class="button button4"><a id="txt" href="bookevent.php">Register</a></button> 
          </div>
          
        </div>
        <br>
</div>
<br><br>
<div class="container">
        <div class="row">

          <div class="col-sm-4 imghov">
            <br>
            <h5>DARK</h5>
            <br>
            <img class="row-image" src="i7.jpg">
          </div>

          <div class="col-sm-8 imghov">
            <br><br>
            <p ><pre style="color:white ;font-family: 'Xanh Mono', monospace;">
            Spanning two centuries, night photography has captured the collective imagination 
            of the masses.
            From the infamously long exposures required by early artists, to high speed color 
            films and the advent of digital technology, the subject of the night
            has inspired an explosion of interest among contemporary artists.
            Natural vistas, celestial bodies, urban landscapes, factories, artificial 
            structures and nocturnal interludes represent but a few of the limitless 
            subjects of nighttime photography.

            DATE OF EVENT: 3th-6th January
            </pre></p>
            <button class="button button4"><a id="txt" href="bookevent.php">Register</a></button> 
          </div>
          
        </div>
        <br>
</div>
<br><br>
</div>
</body>
</html>
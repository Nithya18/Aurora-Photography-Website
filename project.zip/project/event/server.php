<?php
if(isset($_POST['submit']))
{
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbName="lightbox";
        $link = new mysqli($servername, $username, $password, $dbName);

        $uname= mysqli_real_escape_string($link,$_POST['Name']);
        $uevent= mysqli_real_escape_string($link,$_POST['event']);
        $query="SELECT  U_Name,events FROM bookevent WHERE U_Name='$uname' and events='$uevent'";
        $result = mysqli_query($link, $query); 

        if(mysqli_num_rows($result)>0) {
            while($row=  mysqli_fetch_assoc($result)){
                    echo"<script>alert('You have already registered for this event!')</script>";
                
            }
               
        }

        else{
        $sql = "INSERT INTO bookevent(        U_Name,
                                             U_email,
                                             U_pNumber,
                                              events)
                VALUES (                            '".$_POST["Name"]."',
                                                    '".$_POST["email"]."',
                                                    '".$_POST["pNumber"]."',
                                                    '".$_POST["event"]."')";
                        }
        
                }
                        mysqli_close($link);
?>


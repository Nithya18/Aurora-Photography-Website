<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="stylef.css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@500&display=swap" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Required meta tags -->
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" />

</head>
<body>


<!-- navbar  -->
<div class="navbar">
    <a id="main" class="logo" href="index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="index.php">Home</a></li>
<li><a id="head" href="event/events.php">Events</a></li>
<li><a id="head" href="gallery.php">Gallery</a></li>
<!-- <li><a id="head" href="users/">Login/Upload</a></li> -->
<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="user/index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="user/login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>

</ul>
</div>

<!-- start parallax -->
<div class="bgimg-1">
  <div class="caption">
  <span class="border">DISCOVER</span>
  </div> 
</div>

<div style="color: #777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
  <h3 style="text-align:center;">TOGETHER</h3>
  <p>We're all under the same sky and walk the same earth; we're alive together during the same moment.</p></div>

<div class="bgimg-2">
  <div class="caption">
  <span class="border" style="background-color:transparent;font-size:25px;color: #f7f7f7;">EPIPHANY</span>
  </div>
</div>

<div style="position:relative;">
  <div style="color:#ddd;background-color:#D6D0D2  ;text-align:center;padding:50px 80px;text-align: justify;">
  <p>Difficult roads lead to beautiful destinations.</p>
  </div>
</div>

<div class="bgimg-3">
  <div class="caption">
  <span class="border" style="background-color:transparent;font-size:25px;color: #f7f7f7;">TRANQUILITY</span>
  </div>
</div>

<div style="position:relative;">
  <div style="color:#ddd;background-color:#F3BFCD ;text-align:center;padding:50px 80px;text-align: justify;">
  <p>The past is a black hole, cut into the present day like a wound, and if you come too close, you can get sucked in. You have to keep moving.</p>
  </div>
</div>

<div class="bgimg-1">
  <div class="caption">
  <span class="border">SERENDIPITY</span>
  </div>
</div>
<!-- end of parallax -->

<div class="betternet-wrapper">
<footer style="background-color:black;" class="page-footer font-small stylish-color-dark pt-4">

      <!-- Footer Links -->
      <div class="container text-center text-md-left">

        <!-- Grid row -->
        <div style="color: beige;" class="row">

          <!-- Grid column -->
          <div class="col-md-4 mx-auto">

            <!-- Content -->
            <h5 class="font-weight-bold text-uppercase mt-3 mb-4">ABOUT US</h5>
            <p style="color:white;">Over 2 million free high-resolution images brought to you by the world’s most generous community of photographers.</p>

          </div>

          <!-- Grid column -->

          <hr class="clearfix w-100 d-md-none">

          <!-- Grid column -->
          <div class="col-md-2 mx-auto">

            <!-- Links -->
            <h5 class="font-weight-bold text-uppercase mt-3 mb-4">CONTACT US</h5>

            <ul class="list-unstyled">
              <li>
                <a href="#!">+34 5667 4332 244</a>
              </li>
              <li>
                <a href="#!">CONTACT@aurora@gmail.com</a>
              </li>

            </ul>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row -->

      </div>
      <hr>
      <!-- Footer Links -->     

      <!-- Copyright -->
      <div style="background-color: bisque;" class="footer-copyright text-center py-3">© 2020 Copyright:
        <a href="index.html">AURORA.com</a>
      </div>
      <!-- Copyright -->

    </footer>
</div></body>
</html>

<!-- Navbar container -->
<!-- <div>
      <nav class="navbar navbar-expand-md bg-transparent navbar-dark fixed-top">
        <a class="navbar-brand" href="../index.php">LIGHTBOX</a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            
            <li class="nav-item active">
              <a class="nav-link" href="../gallery.php">GALLERY</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="#">MY GALLERY</a>
            </li>
           
            
          </ul>
          <form class="form-inline d-flex justify-content-center md-form form-sm active-pink active-pink-2 mt-2">
            <i class="fa fa-search"></i>
            <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search" aria-label="Search">
          </form>
        </div>
      </nav>
    </div> -->
    <!-- Navbar container end -->
    <div class="navbar">
    <a id="main" class="logo" href="index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="index.php">Home</a></li>
<li><a id="head" href="events.php">Events</a></li>
<li><a id="head" href="gallery.php">Gallery</a></li>
<!-- <li><a id="head" href="users/">Login/Upload</a></li> -->
<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="user/index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="user/login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>

</ul>
</div>
    
<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }
?>

<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

<!DOCTYPE html>
<html>
 <head>
 <title>Pics</title>    
 
<!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <link  rel="stylesheet" type="text/css" href="style1.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" />
</head>
<body>
<div>
<div class="navbar">
    <a id="main" class="logo" href="../index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="../index.php">Home</a></li>
<li><a id="head" href="../event/events.php">Events</a></li>
<li><a id="head" href="../gallery.php">Gallery</a></li>
<!-- <li><a id="head" href="users/">Login/Upload</a></li> -->
<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="../user/index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="../user/login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>
    </div>

</div>
<br><br>
<div class="img">
<?php 

// Include the database configuration file  
require_once 'dbConfig.php'; 
 
// Get image data from database 
$result= $db->query("SELECT image FROM images WHERE user_id ='" . $_SESSION['username'] . "'")
?>
</div>



<?php if($result->num_rows > 0){ ?> 
    <div class="images"> 
        <center><h2 style="color:black">YOUR GALLERY</h2></center>
        <?php while($row = $result->fetch_assoc()){ ?> 
            <img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" width="300" height="200"> 
        <?php } ?> 
    </div> 
<?php }else{ ?> 
    <p class="status error">Image(s) not found...</p> 
<?php } ?>
</body>
</html>
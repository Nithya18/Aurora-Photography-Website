<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }
?>

<!DOCTYPE html>
<html>
<head>  
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <link  rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" />
</head>

<body> 

<div>
      <!-- <nav class="navbar navbar-expand-md bg-transparent navbar-dark fixed-top">
        <a class="navbar-brand" href="../index.php" alt="home" >
         <svg width="2.7em" height="2.7em" viewBox="0 0 16 16" class="bi bi-house-fill" fill="black" xmlns="http://www.w3.org/2000/svg">
         <path fill-rule="evenodd" d="M8 3.293l6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
         <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
        </svg></a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          
          <a href="view.php"><svg width="2.5em" height="2.5em" viewBox="0 0 16 16" class="bi bi-suit-spade-fill" fill="black" xmlns="http://www.w3.org/2000/svg">
  <path d="M5.602 14.153C6.272 13.136 7.348 11.28 8 9c.652 2.28 1.727 4.136 2.398 5.153.231.35-.02.847-.438.847H6.04c-.419 0-.67-.497-.438-.847z"/>
  <path d="M4.5 12.5A3.5 3.5 0 0 0 8 9a3.5 3.5 0 1 0 7 0c0-3-4-4-7-9-3 5-7 6-7 9a3.5 3.5 0 0 0 3.5 3.5z"/>
</svg></a>
        </div>
      </nav> -->
      <div class="navbar">
    <a id="main" class="logo" href="../index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="../index.php">Home</a></li>
<li><a id="head" href="../event/events.php">Events</a></li>
<li><a id="head" href="../gallery.php">Gallery</a></li>
<!-- <li><a id="head" href="users/">Login/Upload</a></li> -->
<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="../user/index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="../user/login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>
    </div>





<center> 
 <svg width="3em" height="3em" viewBox="0 0 16 16" class="bi bi-images" fill="black" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M12.002 4h-10a1 1 0 0 0-1 1v8l2.646-2.354a.5.5 0 0 1 .63-.062l2.66 1.773 3.71-3.71a.5.5 0 0 1 .577-.094l1.777 1.947V5a1 1 0 0 0-1-1zm-10-1a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-10zm4 4.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/>
  <path fill-rule="evenodd" d="M4 2h10a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1v1a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2h1a1 1 0 0 1 1-1z"/>
</svg></center>


 <center><h2 style="color:black">UPLOAD IMAGE</h2></center>

 
 

  <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

<?php  if (isset($_SESSION['username'])) : ?>
<center><p><strong>Welcome <?php echo $_SESSION['username']; ?></strong></p></center>
 <?php endif ?>
 <center><p>________________________________________________________________________________</p></center>
<form action="upload.php" method="post" enctype="multipart/form-data">
<div class="wrap" >
    <label>Select Image File:</label><br>
    <label class="custom">
    <input class="fil" type="file" name="image"><br>
    </label>
    <input class="fill" type="submit" name="submit" value="Upload">
</div>  
</form>


</body>
</html>
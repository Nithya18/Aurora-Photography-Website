<?php 
  session_start(); 
  
  if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
  
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style3.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" />
    
</head>
<body>
<div>
    <div class="navbar">
    <a id="main" class="logo" href="../index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="../index.php">Home</a></li>
<li><a id="head" href="../event/events.php">Events</a></li>
<li><a id="head" href="../gallery.php">Gallery</a></li>
<!-- <li><a id="head" href="users/">Login/Upload</a></li> -->
<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>

</ul>
</div>
      </div>
 

<div class="header">
	<h2 style="color:white">Home</h2>
	<center><p style="color:white">. . . . . . . _____________________________________________________ . . . . . . </p></center>
</div>
<div class="wrap">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	<center><p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p></center>
    	<button class="submitbtn" ><a id="head" href="index.php?logout='1'" style="color:white">logout</a></button>
    <?php endif ?>
    <ul>

    <li><h6><strong><a id="head" href="../submit" style="color:white">UPLOAD PICTURE</a></strong><h6></li>
    <li><h6><strong><a id="head" href="../event/events.php" style="color:white">Take part in Events</a></strong></h6></li>
    <li><h6><strong><a id="head" href="../submit/view.php" style="color:white">Your Gallery</a></strong></h6></li>
</div>
		
</body>
</html>
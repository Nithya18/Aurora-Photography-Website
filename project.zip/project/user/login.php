<?php include('server.php') ?>
<?php if(isset($_SESSION['username'])){
    header('location:index.php');
}?>

<!DOCTYPE html>
<html>
<head>
  <title>LOGIN</title>
  <link rel="stylesheet" type="text/css" href="style1.css"> 
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@500&display=swap" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Required meta tags -->
<meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" />



  </head>
<body>

<!-- <div class="parent-container"> -->
<div class="navbar">
    <a id="main" class="logo" href="../index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="../index.php">Home</a></li>
<li><a id="head" href="../event/events.php">Events</a></li>
<li><a id="head" href="../gallery.php">Gallery</a></li>
<!-- <li><a id="head" href="users/">Login/Upload</a></li> -->
<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>

</ul>
</div>
 
     <?php include('errors.php'); ?> 

   
   <form method="post">
   <div class="wrap" >
     <h2>SIGN IN</h2>
     
        <input class="ipfield" type="text" name="username"  placeholder="Username" >
     
        <input class="ipfield"  placeholder="Password" type="password" name="password">
     
        <button type="submit" class="submitbtn" name="login_user">LOGIN</button>
        
        <center><p style="color:white">
  		  Don't Have an account? <a href="register.php" style="color:rgb(248, 236, 236)">SIGN UP</a>
  	    </p></center> 
    </div>
</div>


  

</body>
</html>



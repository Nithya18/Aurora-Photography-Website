<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Register</title>
  <link rel="stylesheet" type="text/css" href="style2.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous" />
    

</head>
<body>

    <div>
    <div class="navbar">
    <a id="main" class="logo" href="../index.php">AURORA</a>
    <ul class="nav">
<li><a id="head" href="../index.php">Home</a></li>
<li><a id="head" href="../events.php">Events</a></li>
<li><a id="head" href="../gallery.php">Gallery</a></li>
<!-- <li><a id="head" href="users/">Login/Upload</a></li> -->
<?php if (isset($_SESSION['success'])) { ?>
             <li><a id="head" href="index.php"><?php echo $_SESSION['username'];?></a></li>
            <?php } else {?>
            <li><a id="head" href="login.php">LOGIN/UPLOAD</a></li>
            <?php } ?>

</ul>
</div>
      </div>
 
 <form  method="post" action="register.php">
 
   <div class="wrap">
	 <h2>SIGN UP</h2>
	 <?php include('errors.php'); ?>
     
        <input class="ipfield" type="text" name="username"  placeholder="Username" value="<?php echo $username; ?>">
     
        <input class="ipfield"  placeholder="Email" type="email" name="email" value="<?php echo $email; ?>">
     
        <input class="ipfield"  placeholder="Password" type="password" name="password_1">
     
        <input  class="ipfield" placeholder="Confirm password" type="password" name="password_2">

        <button type="submit" class="submitbtn" name="reg_user">Register</button>
        
        <center><p style="color:white">
  		  Already Have an account? <a href="login.php" style="color:rgb(248, 236, 236)">SIGN IN</a>
  	    </p></center> 
	</div>
</div>	
</body>
</html>


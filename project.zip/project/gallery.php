<?php 
// include database connection 
include "submit/dbConfig.php"; 
 ?>

<!DOCTYPE html>
<html>
 <head>  
 <link  rel="stylesheet" type="text/css" href="styleg.css">
 <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<center><h1 style="color:white;">GALLERY</h1></center>
<center><p style="color:white;">__________________________________________________________________</p></center>
<!-- Container for our gallery -->
<div class="container"> 
<?php
$result = $db->query("SELECT image FROM images ORDER BY uploaded DESC"); 
?>
 <!-- Main view of our gallary -->
 <div class="main_view"> 
   <center> <img src="i4.jpg" id="main" alt="IMAGE"></center>
  </div>

<?php if($result->num_rows > 0){ ?> 
    <!-- All images with side view -->
    <div class="side_view">  
        
        <!-- <div style="background-image: url('i1.jpg');"> -->
        <?php while($row = $result->fetch_assoc()){ ?> 
           <center> <img onclick="change(this.src)" src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" width="300" height="200"> </center>
        <?php } ?> 
    </div> 
<?php }else{ ?> 
    <p class="status error">Image(s) not found...</p> 
<?php } ?>
</div>  

<script type="text/javascript"> 
        const change = src => { 
            document.getElementById('main').src = src 
        } 
    </script>  
   
</body>
</html>